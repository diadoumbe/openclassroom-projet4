<!DOCTYPE html>
 <html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="Description" content="ouvrage Billet simple pour l'alaska par jean Forteroche.">
    <meta name="Keywords" content="roman jean forteroche">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    <title>Billet simple pour l'alaska, par jean Forteroche</title>
  </head>

  <body>
  
    <div id="global">
       <?php include (" ./../header.php");?>
       
       <?php include (" ./../poster.php");?>
       
       <section class="rubrique">
                 <h3>Accueil</h3>
       </section>
       
       <!-- affichage de tous les billets -->       
       <section class="un">
           
           <?php if (!empty($billets)){?>
            <h3 class="titrerubrique">Articles:</h3>
          <?php }?>
            
             <?php if (empty($billets)){echo "AUCUN ARTICLE PUBLIE!";
              }else {?>
           
             <?php foreach ($billets as $billet): ?>
             
            <div class="cadrebillet">
            
                <h2>
                    <strong><?= htmlspecialchars($billet->titreb()) ?> </strong>
               </h2>
               
                <h4>
                     <time><i>Edite le: <?= $billet->dateb() ?> </i></time>
                     &nbsp;&nbsp;&nbsp;&nbsp;
                     auteur:<em> <?= htmlspecialchars($billet->auteurb()) ?> </em>
               </h4>

                <div class="textuel"><?= $billet->messageb() ?> </div>

                <table class="tablebillet">
                  <tr>
                      <td>
                          <a href=" ./controler/billet.php?idbillet=<?php echo $billet->idb(); ?>">Voir Article et commentaires</a>
                      </td>
                                   
                      <td>
                          <a href=" ./controler/billet.php?idbillet=<?php echo $billet->idb(); ?>">Ajoutez un commentaire</a>
                      </td>
                  </tr>
                </table>                                                       

           </div> 
              
            <?php endforeach; ?>
            
            <?php }?>   
                 
       </section>
 
       <?php include (" ./../footer.php");?>
             
    </div>
    
  </body>

 </html>

