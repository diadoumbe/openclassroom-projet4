<?php header( 'content-type: text/html; charset=utf-8' );

require_once '../../function.php';
require_once '../../classbillet.php';
require_once '../../classcomment.php';
require_once '../../modele/manager.php';

$manager= new Managerbc($db);

//LISTER TOUS LES COMMENTAIRES SIGNALES
$signals=$manager->signalistc();

    $message1bis="";        

//AFFICHER lE BILLET ET LE COMMENTAIRE SIGNALE

if (isset($_GET['idbilletsignal']) && isset($_GET['idcomsignal']))
{
	
	$idb=(int)$_GET['idbilletsignal'];
	$idc=(int)$_GET['idcomsignal'];
	
	$billet=$manager->getb($idb);
	$comment=$manager->getc($idc);
	
	$signals=$manager->signalistc();

}

//MODIFIER COMMENTAIRE
/*
if (isset($_POST['updc'])){
	$comment= new Comment([
			'idc'=>$_POST['idc'],
			'idbc'=>$_POST['idbc'],
			'auteurc'=>$_POST['auteurc'],
			'titrec'=>$_POST['titrec'],
			'commentc'=>$_POST['commentc'],
	]);

	if ($comment->validc()){
		$manager->updatec($comment);
		$message='COMMENTAIRE MODIFIE!';
	}
	//$message='';
}  */

//SUPPRIMER UN COMMENTAIRE

if (isset($_GET['delc']))
{
	$delc=(int)$_GET['delc'];

	$manager->deletec($delc);

	$message1='COMMENTAIRE SUPPRIME!';
	
	$signals=$manager->signalistc();
	
}

require '../vue/adsignalvue.php';


