<?php header( 'content-type: text/html; charset=utf-8' );

require_once '../../function.php';
require_once '../../classbillet.php';
require_once '../../classcomment.php';
require_once '../../modele/manager.php';

$manager= new Managerbc($db);

//LISTER TOUS LES BILLETS

$billets=$manager->getListb();
 
//AJOUT BILLET

if (isset($_POST['addb']) && !empty($_POST['auteurb']) && !empty($_POST['titreb']) && !empty($_POST['messageb']))
{
	$billet= new Billet([
			'auteurb'=>$_POST['auteurb'],
			'titreb'=>$_POST['titreb'],
			'messageb'=>$_POST['messageb'], 
	]);

	if ($billet->validb()){
		$res=$manager->addb($billet);
      $message='ARTICLE AJOUTE!';
      
      
      $billets=$manager->getListb();
		//if($res){ $message='Article ajout�!';}
	 unset($_POST);
	 header("location:admin.php?message=$message");
	 exit();
		
	}
	else {$message="ECHEC AJOUT ARTICLE!";
	      $erreurs=$billet->erreurslistb();
	      
	      $billets=$manager->getListb();
	     }
	
}

//SUPPRIMER BILLET

if (isset($_GET['delb']))
{
	$delb=(int)$_GET['delb'];
	
	$manager->deleteb($delb);
	$manager->deleteListc($delb);
	
	$message='ARTICLE SUPPRIME!';
	
	$billets=$manager->getListb();
	
}

require '../vue/adminvue.php';