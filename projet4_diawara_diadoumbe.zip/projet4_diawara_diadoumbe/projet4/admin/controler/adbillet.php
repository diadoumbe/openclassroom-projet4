<?php header( 'content-type: text/html; charset=utf-8' );

require_once '../../function.php';
require_once '../../classbillet.php';
require_once '../../classcomment.php';
require_once '../../modele/manager.php';

$manager=new Managerbc($db);

$idb;

//AFFICHER BILLET ET SES COMMENTAIRES

if (isset($_GET['idbillet'])){
	
	 $idb=(int)$_GET['idbillet'];
	 

	 $billet=$manager->getb($idb);
	 $comments=$manager->getListc($idb);
	 	 	
}

//MODIFIER BILLET

if (isset($_POST['updb']) && !empty($_POST['idb']) && !empty($_POST['auteurb']) && !empty($_POST['titreb']) && !empty($_POST['messageb']) )
 {
	
	$idb=(int)$_POST['idb'];
	
	$billet= new Billet([
			'idb'=>$_POST['idb'],
			'auteurb'=>$_POST['auteurb'],
			'titreb'=>$_POST['titreb'],
			'messageb'=>$_POST['messageb'],
	]);

	if ($billet->validb()){
		$res=$manager->updateb($billet);
		$message='ARTICLE MODIFIE!';
		
		$billet=$manager->getb($idb);
		$comments=$manager->getListc($idb);
		
		//$message='BILLET MODIFIE!';
		
			
		//header("location:adbillet.php?idbillet=$idbc&ampmessage=$message");
		//exit();
		
	}
	else {
		  $message="ECHEC MODIFICATION ARTICLE!";
	      $erreurs=$billet->erreurslistb();
	      
	      $billet=$manager->getb($idb);
	      $comments=$manager->getListc($idb);
	      
	     }
	
}

//SUPPRIMER BILLET

if (isset($_GET['delb'])){
	$delb=(int)$_GET['delb'];
	
	$manager->deleteb($delb);
	$manager->deleteListc($delb);
	
	$billet=$manager->getb($delb);
	$comments=$manager->getListc($delb);
	
	$message='ARTICLE SUPPRIME!!';
		
	//require 'adbillet.php';
}

//SUPPRIMER UN COMMENTAIRE

if (isset($_GET['delc']) && isset($_GET['delidb'])){
	
	$delc=(int)$_GET['delc'];
	
	$delibc=(int)$_GET['delidb'];

	$manager->deletec($delc);

	$billet=$manager->getb($delibc);
	$comments=$manager->getListc($delibc);
	
	$message1='COMMENTAIRE SUPPRIME!';
	
}


require '../vue/adbilletvue.php';

