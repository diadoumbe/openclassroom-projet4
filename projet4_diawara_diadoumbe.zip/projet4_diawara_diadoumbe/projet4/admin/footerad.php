<footer>

  <div>
     <img alt="billet simple pour l'alaska" src="../../image/ecrivain2.jpg">
  </div>
   
   <nav>

    <ul>
        <li>
            <a href="../controler/admin.php">Accueil administration</a>
        </li>
        
        <li>
            <a href="../controler/admin.php">Tous les articles</a>
        </li>
        
        <li>
            <a href="../controler/admin.php">Ajouter article</a>
        </li>
        
        <li>
            <a href="../controler/adsignal.php">Commentaires signales</a>
        </li>
        
        <li>
            <a href="../../index.php">Accueil site</a>
        </li>    
        
    </ul>  
  
  </nav>

</footer>

