<!DOCTYPE html>
 <html>

  <head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="Description" content="ouvrage Billet simple pour l'alaska par jean Forteroche.">
    <meta name="Keywords" content="roman jean forteroche">
     <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    <script src="https://kit.fontawesome.com/bf2f2c9ab5.js" crossorigin="anonymous"></script>
     <link rel="stylesheet" type="text/css" href="../../style.css">   
    <title>Billet simple pour l'alaska, par jean Forteroche</title>
  </head>

  <body>
  
    <div id="global">
    
       <?php include ("../adheader.php");?>

       <section class="rubrique">
                 <h3>Commentaires signales administration</h3>
       </section>
       
       <!--  affichage article -->
       <section class="un" >
           
           <?php if (isset($billet)){?>
           <h3 class="titrerubrique">Article:</h3>
          <?php }?>
           
                <?php if (!empty($message)){echo'<h3 class="actionok">'.htmlspecialchars($message).'</h3> ';} ?> 
                
               <?php if (!empty($billet)){ ?> 
                     
           <div class="cadrebillet">           
                            <h2>
                                <strong>
                                       <?= htmlspecialchars($billet->titreb())  ?>                                 
                               </strong>
                            </h2> 
                                                                            
                            <h4>
                                <time>
                                 <i>
                                    Edite le: <?= $billet->dateb()  ?>                                  
                                </i>
                               </time>
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                auteur:
                                <em>
                                    <?= htmlspecialchars($billet->auteurb())  ?>                                  
                                </em>
                            </h4>                                                  
                                                                             
                            <div class="textuel">
                              <?=  $billet->messageb() ?>                                  
                            </div>                
           </div>
           
            <?php }?>
           
       </section>


<section class="un">
          
          <?php if (!empty($comment)){?>
          <h3 class="titrerubrique">Commentaire:</h3>
         <?php }?>
          
         <?php if (!empty($message1)){echo'<h3 class="actionok">'.htmlspecialchars($message1).'</h3> ';} ?>
         
          <?php if (!empty($comment)){ ?>
         
           <div class="cadrecomment">
             
            <?php if ($comment->signalc()==1){?> <h3 class="alert">Commentaire signale!</h3> <?php }?>
             
                <h2>
                    <strong><?= htmlspecialchars($comment->titrec()) ?> </strong>
                </h2>                

                <h4>
                    <time><i>Edite le: <?= $comment->datec() ?> </i></time>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    auteur:<em><?= htmlspecialchars($comment->auteurc()) ?> </em>
               </h4>

                <div class="textuel"><?=  htmlspecialchars($comment->commentc()) ?> </div>

                <table class="tablecomment">
                  
                  <tr>
                      <td>
                          <a href="../controler/adsignal.php?delc=<?php echo $comment->idc(); ?>">Supprimer commentaire</a>
                      </td>
                  </tr>
                </table>

           </div> 

            <?php }?>     

       </section>
   
       
       <!-- affichage de tous les commentaires de l article -->       
       <section class="un">
          
          <?php if (!empty($signals)){?>
          <h3 class="titrerubrique">Commentaires:</h3>
         <?php }?>
          
         <?php if (isset($message1bis)){echo'<h3 class="actionok">'.htmlspecialchars($message1bis).'</h3> ';} ?>
         
           <?php if (empty($signals)){echo "AUCUN COMMENTAIRES SIGNALES!";
           }else {?>
                      
             <?php foreach ($signals as $signal): ?>
             
           <div class="cadrecomment">
             
            <?php if ($signal->signalc()==1){?> <h4 class="alert">Commentaire signale!</h4> <?php }?>
             
                <h2>
                    <strong><?= htmlspecialchars($signal->titrec()) ?> </strong>
               </h2>                

                <h4>
                     <time><i>Edite le: <?= $signal->datec() ?> </i></time>
                     &nbsp;&nbsp;&nbsp;&nbsp;
                     auteur:<em><?= htmlspecialchars($signal->auteurc()) ?> </em>
               </h4>

                <div class="textuel"><?= htmlspecialchars( $signal->commentc()) ?> </div>

                <table class="tablecomment">
                  <tr>
                      <td>
                          <a href="../controler/adsignal.php?idbilletsignal=<?php echo $signal->idbc(); ?>&idcomsignal=<?php echo $signal->idc(); ?>">Gerer article et commentaires</a>
                      </td>
                  
                      <td>
                          <a href="../controler/adsignal.php?delc=<?php echo $signal->idc(); ?>">Supprimer commentaire</a>
                      </td>
                  </tr>
                 
                </table>                                                          

           </div> 
           
           <?php endforeach; ?>
               
             <?php }?>
                  
       </section>
 
       <?php include ("../footerad.php");?>
             
    </div>
    
  </body>

 </html>



