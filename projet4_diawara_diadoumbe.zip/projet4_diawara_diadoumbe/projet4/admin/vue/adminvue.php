<!DOCTYPE html>
 <html>

  <head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="Description" content="ouvrage Billet simple pour l'alaska par jean Forteroche.">
    <meta name="Keywords" content="roman jean forteroche">
     <link rel="stylesheet" type="text/css" href="../../style.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    <title>Billet simple pour l'alaska, par jean Forteroche</title>
  </head>

  <body>
  
    <div id="global">
       <?php include ("../adheader.php");?>
       
       <section class="rubrique">
       
                 <h3>Accueil administration</h3>
       </section>
       
       <!-- ajout d article -->
       <section class="un">
           
           <h3 class="titrerubrique">Ajout article:</h3>
           
                <?php if (!empty($_GET['message'])){echo'<h3 class="actionok">'.htmlspecialchars($_GET['message']).'</h3> ';} ?>
       
           <div class="cadrebillet">
           
                <form action="../controler/admin.php" method="post" id="formbillet">
                
                      <fieldset>
                       
                         <legend>AJOUTER ARTICLE</legend>
                      
                            <p><?php if (isset($erreurs)&& in_array(Billet::TITREB_FAU, $erreurs)) echo 'TITRE INVALIDE!'; ?>
                               <label>
                                      Titre:
                               </label>
                                  <input type="text" required="required" name="titreb" pattern="[a-zA-Z _-]{1,50}" title="titre,50lettres max ex:a-z0-9">
                                  
                            </p>
                            
                      
                            <p><?php if (isset($erreurs)&& in_array(Billet::AUTEURB_FAU, $erreurs)) echo 'AUTEUR INVALIDE!'; ?>
                               <label>
                                      Auteur:
                               </label>
                                  <input type="text" required="required" name="auteurb" pattern="[a-zA-Z _-]{1,50}" title="auteur,50lettres max ex:a-z0-9">
                                  
                            </p>
                            
                      
                            <p><?php if (isset($erreurs)&& in_array(Billet::MESSAGEB_FAU, $erreurs)) echo 'ARTICLE INVALIDE!'; ?>
                               <label>
                                      Article:
                               </label>
                                  <textarea rows="12" cols="" required="required" name="messageb" id="messageb"> </textarea>
                                  
                           </p>
                                 
                          <p>
                             <input type="submit" value="ajouter" name="addb">
                          </p>
                          
                      </fieldset>                     
                      
                </form>
                
           </div>
           
       </section>
       
       <!-- affichage de tous les billets -->       
       <section class="un">
             
             <?php if (!empty($billets)){?>
             <h3 class="titrerubrique">Articles:</h3>
            <?php }?>
            
            <?php if (!empty($message)){echo'<h3 class="actionok">'.htmlspecialchars($message).'</h3> ';} ?>
             
           <?php if (empty($billets)){echo "AUCUN ARTICLE PUBLIE!";
              }else {?>                            
                  
             <?php foreach ($billets as $billet): ?>
             
             <div class="cadrebillet">
             
                <h2>
                    <strong><?= htmlspecialchars($billet->titreb()) ?> </strong>
                </h2>                

                <h4>
                    <time><i>Edite le: <?= $billet->dateb() ?> </i></time>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    auteur: <em><?= htmlspecialchars($billet->auteurb()) ?> </em>
               </h4>

                <div class="textuel"><?= $billet->messageb()  ?> </div>

                <table class="tablebillet">
                  <tr>
                      <td>
                          <a href="../controler/adbillet.php?idbillet=<?php echo $billet->idb(); ?> " >Gerer article et commentaires</a>
                      </td>
                 
                      <td>
                          <a href="../controler/admin.php?delb=<?php echo $billet->idb(); ?> " >Supprimer article</a>
                      </td>
                  
                      <td>
                          <a href="../controler/adbillet.php?idbillet=<?php echo $billet->idb(); ?> " >Modifier article</a>
                      </td>
                  </tr>
                </table>                                                         

           </div> 
            
             <?php endforeach; ?>
            
          <?php }?>
                 
       </section>
 
       <?php include ("../footerad.php");?>
             
    </div>
    
    <script type="text/javascript" src="../tinymce_3.5.12/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
    <script type="text/javascript" src="../mce.js"></script>
    <script type="text/javascript" src="../inittinymce.js"></script>
  </body>

 </html>

