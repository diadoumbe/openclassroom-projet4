<!DOCTYPE html>
 <html>

  <head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="Description" content="ouvrage Billet simple pour l'alaska par jean Forteroche.">
    <meta name="Keywords" content="roman jean forteroche">
     <link rel="stylesheet" type="text/css" href="../../style.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    <title>Billet simple pour l'alaska, par jean Forteroche</title>
  </head>

  <body>
  
    <div id="global">
    
       <?php include ("../adheader.php");?>
       
       <section class="rubrique">
                 <h3>Article et commentaires administration</h3>
       </section>
       
       <!--  modification article -->
       <section class="un" >
           
           <h3 class="titrerubrique">Article:</h3>
           
                <?php if (isset($message)){echo'<h3 class="actionok">'.htmlspecialchars($message).'</h3> '; } ?>
 
                <?php if (empty($billet)){echo "<a href='admin.php'>SELECTIONNEZ UN ARTICLE, ici!</a>";
                }else {?>
       
           <div class="cadrebillet">
           
                <form action="../controler/adbillet.php" method="post" id="formbillet">
                
                      <fieldset>
                       
                         <legend>MODIFIER ARTICLE</legend>
                      
                            <p> <?php if (isset($erreurs)&& in_array(Billet::TITREB_FAU, $erreursb)) echo 'TITRE INVALIDE!'; ?>
                               <label>
                                      Titre:
                               </label>
                                  <input type="text" value="<?= htmlspecialchars($billet->titreb())  ?> " required="required" name="titreb" pattern="[a-zA-Z _-]{1,50}" title="titre,50lettres max ex:a-z0-9">
                                  
                            </p>
                            
                      
                            <p><?php if (isset($erreurs)&& in_array(Billet::AUTEURB_FAU, $erreursb)) echo 'AUTEUR INVALIDE!'; ?>
                               <label>
                                      Auteur:
                               </label>
                                  <input type="text" value="<?= $billet->auteurb()  ?>" required="required" name="auteurb" pattern="[a-zA-Z _-]{1,50}" title="auteur,50lettres max ex:a-z0-9">
                                  
                            </p>
                            
                      
                            <p>
                                Edite le: <?= $billet->dateb()  ?>                                  
                            </p>
                            
                      
                            <p><?php if (isset($erreurs)&& in_array(Billet::MESSAGEB_FAU, $erreursb)) echo 'ARTICLE INVALIDE!'; ?>
                               <label>
                                      Article:
                               </label>
                                 
                                  <textarea rows="12" cols=""  required="required" name="messageb" id="messageb1"><?= htmlspecialchars(nl2br( $billet->messageb()))?> </textarea>
                                  
                            </p>
                                 <input type="hidden" value="<?= $billet->idb() ?>" name="idb">

                          <p>
                             <input type="submit" value="modifier" name="updb">
                          </p>
                          
                      </fieldset>                     
                      
                </form>

                <p>
                   <a class="abouton" href="../controler/adbillet.php?delb=<?php echo $billet->idb(); ?>">Supprimer article</a>
                </p>             
                
           </div>
         
          <?php }?>
           
       </section>
       
       <!-- affichage de tous les commentaires de l article -->       
       <section class="un">
            
            <?php if (!empty($comments)){?>
            <h3 class="titrerubrique">Commentaires:</h3>
            <?php }?>
            
         <?php if (isset($message1)){echo '<h3 class="actionok">'.$message1.'</h3>';} ?>
       
        <?php  if (empty($comments)){echo "AUCUN COMMENTAIRES!";
         }else {?>       
           
             <?php foreach ($comments as $comment): ?>
             
            <div class="cadrecomment">
             
            <?php if ($comment->signalc()==1){?> <h3 class="alert">Commentaire signale!</h3> <?php }?>
             
                <h2>
                    <strong><?= htmlspecialchars($comment->titrec()) ?> </strong>
                </h2>                

                <h4>
                    <time><i>Edite le: <?= $comment->datec() ?> </i></time>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    auteur:<em><?= htmlspecialchars($comment->auteurc()) ?> </em>
               </h4>

                <div class="textuel"><?= htmlspecialchars($comment->commentc()) ?> </div>

                <table class="tablecomment">
                  <tr>
                      <td>
                          <a href="../controler/adbillet.php?delc=<?php echo $comment->idc(); ?>&delidb=<?php echo $comment->idbc(); ?>">Supprimer commentaire</a>
                      </td>
                  </tr>
                </table>                                        

           </div> 
          
          <?php endforeach; ?>
               
          <?php  }?>     
                 
       </section>
 
       <?php include ("../footerad.php");?>
             
    </div>
    <script type="text/javascript" src="../tinymce_3.5.12/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
    <script type="text/javascript" src="../mce.js"></script>
    <script type="text/javascript" src="../inittinymce.js"></script>
  </body>

 </html>


