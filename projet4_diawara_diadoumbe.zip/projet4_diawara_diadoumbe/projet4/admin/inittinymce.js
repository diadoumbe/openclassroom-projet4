
//dimension textarea tiny mce
document.getElementById(id+'_tbl').style.width='90%';

document.getElementById(id+'_ifr').style.height='auto';