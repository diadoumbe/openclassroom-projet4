<header>

  <div id="headerlogo">

       <div> 
           <img alt="logo ecrivain" src="../../image/logoecrivain.png" width="120"></div>
       <div>
       
       <span id="titreroman"><strong>BILLET SIMPLE POUR L'ALASKA</strong></span>
       <br>
       <span id="auteurtitre"><em>par jean Forteroche</em></span>
     </div>
  </div>


  <nav>

    <ul>
        <li>
            <a href="../controler/admin.php">Accueil administration</a>
        </li>
        <li>
            <a href="../controler/admin.php">Tous les articles</a>
        </li>
        <li>
            <a href="../controler/admin.php">Ajouter article</a>
        </li>
        <li>
            <a href="../controler/adsignal.php">Commentaires signales</a>
        </li>
        <li>
            <a href="../../index.php">Accueil site</a>
        </li>    
    
    
    </ul>  
  
  </nav>
</header>

