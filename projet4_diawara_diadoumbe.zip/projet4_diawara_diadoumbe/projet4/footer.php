<footer>
 
  <div>
     <img alt="billet simple pour l'alaska" src="image/ecrivain2.jpg">
  </div>
  
  <nav>
    <ul>
     <li>
         <a href="index.php">Accueil</a>      
      </li>
      <li>
         <a href="admin/controler/admin.php">Connexion  administration</a>      
      </li>
      <li>
         <a href="contact.php">Reglement Contact</a>      
      </li>         
    </ul>  
  </nav>

</footer>
