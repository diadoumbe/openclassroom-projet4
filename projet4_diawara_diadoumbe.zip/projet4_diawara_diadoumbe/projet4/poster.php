<section class="un">

    <div>
      <img alt="blog ecrivain" src="image/ecrivain1.jpg" id="poster">    
    </div>
    
</section>
