<?php header( 'content-type: text/html; charset=utf-8' );


require_once 'function.php';
require_once 'classbillet.php';
require_once 'classcomment.php';
require_once 'modele/manager.php';

$manager= new Managerbc($db);

//LISTER TOUS LES BILLETS


$billets=$manager->getListb();

    require 'vue/indexvue.php';
    

