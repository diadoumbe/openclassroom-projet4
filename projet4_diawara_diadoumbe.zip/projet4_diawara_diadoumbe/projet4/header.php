<header>

  <div id="headerlogo">

   <div> <img alt="logo ecrivain" src="image/logoecrivain.png" width="120"></div>
     <div>
       <span id="titreroman"><strong>BILLET SIMPLE POUR L'ALASKA</strong></span>
       <br>
       <span id="auteurtitre"><em>par jean Forteroche</em></span>
     </div>
  </div>

  <nav>

    <ul>
        <li>
            <a href="index.php">Accueil</a>
        </li>

        <li>
            <a href="admin/controler/admin.php">Connexion administration</a>
        </li>
        
    </ul>  
  
  </nav>
</header>
