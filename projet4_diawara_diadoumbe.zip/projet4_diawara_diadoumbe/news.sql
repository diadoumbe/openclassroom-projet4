-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 06 Février 2020 à 17:49
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `news`
--

-- --------------------------------------------------------

--
-- Structure de la table `billet`
--

CREATE TABLE IF NOT EXISTS `billet` (
  `idb` int(11) NOT NULL AUTO_INCREMENT,
  `titreb` varchar(50) COLLATE utf8_bin NOT NULL,
  `messageb` text COLLATE utf8_bin NOT NULL,
  `auteurb` varchar(30) COLLATE utf8_bin NOT NULL,
  `dateb` date NOT NULL,
  PRIMARY KEY (`idb`),
  KEY `idb` (`idb`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=8 ;

--
-- Contenu de la table `billet`
--

INSERT INTO `billet` (`idb`, `titreb`, `messageb`, `auteurb`, `dateb`) VALUES
(1, 'Le parc national Denali                  ', '<div style="text-align: left;"><span style="font-size: large; color: #800000;">La majorit&eacute; des voyageurs qui se rendent en Alaska visitent le parc national Denali au cours de</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #800000;">&nbsp;leur s&eacute;jour. En effet, cette r&eacute;gion spectaculaire est le paradis des amateurs de grands espaces :</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #800000;">&nbsp;vous pourrez faire des excursions en car, de la randonn&eacute;e, du rafting, de la p&ecirc;che, ou encore des</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #800000;">&nbsp;visites touristiques. Les alpinistes chevronn&eacute;s pourront &eacute;galement partir &agrave; l&rsquo;assaut du mont McKinley,</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #800000;">&nbsp;la plus haute montagne d&rsquo;Am&eacute;rique du Nord (elle culmine &agrave; 6168 m&egrave;tres d&rsquo;altitude). Si vous aimez les</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #800000;">&nbsp;grands espaces sauvages, rendez-vous au parc national Denali, un incontournable de votre visite</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #800000;">&nbsp;de l&rsquo;Alaska.</span></div>', 'le naturaliste j Forteroche', '2020-01-18'),
(2, 'Riverboat Discovery  ', '<div style="text-align: left;"><span style="font-size: large; color: #3366ff;">Des bateaux en Alaska ? Eh oui! Si vous s&eacute;journez &agrave; Fairbanks,</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #3366ff;">&nbsp;pourquoi ne pas embarquer dans un bateau &agrave; aube pour une jolie croisi&egrave;re en Alaska de trois heures ? Vous pourrez&nbsp;</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #3366ff;">d&eacute;couvrir la vie moderne, mais aussi les coutumes traditionnelles des personnes de la r&eacute;gion. Vous pourrez m&ecirc;me vous</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #3366ff;">&nbsp;arr&ecirc;ter au village indien de Chena pour voir comment les gens ont r&eacute;ussi &agrave; vivre et &agrave; prosp&eacute;rer depuis des g&eacute;n&eacute;rations</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #3366ff;">&nbsp;malgr&eacute; le rude climat d&rsquo;Alaska. D&eacute;couvrir la vie des locaux, c&rsquo;est &ccedil;a aussi visiter l&rsquo;Alaska.</span></div>', 'le pecheur j Forteroche', '2020-01-18'),
(5, 'Parc national et reserve de Katmai ', '<div style="text-align: left;"><span style="font-size: large; color: #ff0000;">Beaucoup de visiteurs viennent en Alaska dans l&rsquo;espoir de voir des ours, mais peu y arrivent,</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #ff0000;">&nbsp;car les ours sont des animaux discrets qui aiment leur vie priv&eacute;e. Si vous voulez mettre toutes les chances de votre</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #ff0000;">&nbsp;c&ocirc;t&eacute; pour voir des ours, rendez-vous au parc national et r&eacute;serve de Katmai, qui est situ&eacute; pr&egrave;s de la ville de King</span></div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #ff0000;">&nbsp;Salmon au sud-ouest d&rsquo;Anchorage. Ce parc abrite la plus importante population d&rsquo;ours bruns dans le monde. Vous aurez</span></div>\r\n<div style="text-align: left;">&nbsp;</div>\r\n<div style="text-align: left;"><span style="font-size: large; color: #ff0000;">&nbsp;sans doute l&rsquo;occasion de prendre une magnifique photo d&rsquo;eux.</span></div>', 'le chasseur j Forteroche', '2020-01-18'),
(6, 'Le Musee du Nord', '<div style="text-align: left;"><span style="font-size: large;">Partez en excursion &agrave; Fairbanks</span></div>\r\n<div style="text-align: left;"><span style="font-size: large;">&nbsp;et ne manquez pas de d&eacute;couvrir le Mus&eacute;e du Nord, un mus&eacute;e g&eacute;r&eacute; par &laquo; University of Alaska &raquo;.</span></div>\r\n<div style="text-align: left;"><span style="font-size: large;">&nbsp;Ce mus&eacute;e est l&rsquo;une des principales attractions de l&rsquo;Alaska. Il abrite des expositions qui</span></div>\r\n<div style="text-align: left;"><span style="font-size: large;">&nbsp;vous permettront d&rsquo;en savoir plus sur l&rsquo;histoire de cet &eacute;tat am&eacute;ricain. Des anciennes sculptures</span></div>\r\n<div style="text-align: left;"><span style="font-size: large;">&nbsp;inuit aux p&eacute;pites d&rsquo;or en passant par des fourrures de mastodontes et de mammouths, ne manquez pas</span></div>\r\n<div style="text-align: left;"><span style="font-size: large;">&nbsp;de visiter cet incroyable mus&eacute;e au cours de votre s&eacute;jour.</span></div>\r\n<div style="text-align: left;">&nbsp;</div>', 'le botaniste j Forteroche', '2020-01-19'),
(7, 'Le glacier Mendenhall', '<div style="text-align: left;"><span style="color: #333333;"><strong><span style="font-size: large;">La capitale de l&rsquo;Alaska &ndash; n&rsquo;est pas chose ais&eacute;e, car la ville&nbsp;</span></strong></span></div>\r\n<div style="text-align: left;"><span style="color: #333333;"><strong><span style="font-size: large;">n&rsquo;est accessible qu&rsquo;en bateau ou en avion. Mais cette ville en vaut la peine si vous</span></strong></span></div>\r\n<div style="text-align: left;"><span style="color: #333333;"><strong><span style="font-size: large;">&nbsp;cherchez quoi faire en Alaska . Vous pourrez admirer y le Mendenhall, un immense glacier</span></strong></span></div>\r\n<div style="text-align: left;"><span style="color: #333333;"><strong><span style="font-size: large;">&nbsp;de 19 km de long. Situ&eacute; &agrave; 20 km &agrave; peine du centre-ville, il est visible d&rsquo;&agrave; peu pr&egrave;s partout</span></strong></span></div>\r\n<div style="text-align: left;"><span style="color: #333333;"><strong><span style="font-size: large;">&nbsp;en ville. Vous pouvez faire un tour en h&eacute;licopt&egrave;re ce qui vous permettra d&rsquo;admirer une vue</span></strong></span></div>\r\n<div style="text-align: left;"><span style="color: #333333;"><strong><span style="font-size: large;">&nbsp;a&eacute;rienne de ce majestueux glacier. Un lieu &agrave; d&eacute;couvrir si vous souhaitez faire une croisi&egrave;re</span></strong></span></div>\r\n<div style="text-align: left;"><span style="color: #333333;"><strong><span style="font-size: large;">&nbsp;en Alaska.</span></strong></span></div>', 'l alpiniste j Forteroche', '2020-01-20');

-- --------------------------------------------------------

--
-- Structure de la table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `idc` int(11) NOT NULL AUTO_INCREMENT,
  `idbc` int(11) NOT NULL,
  `titrec` varchar(50) COLLATE utf8_bin NOT NULL,
  `commentc` text COLLATE utf8_bin NOT NULL,
  `signalc` tinyint(4) NOT NULL,
  `auteurc` varchar(30) COLLATE utf8_bin NOT NULL,
  `datec` date NOT NULL,
  PRIMARY KEY (`idc`),
  KEY `idc` (`idc`,`idbc`),
  KEY `idbccomment` (`idbc`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=54 ;

--
-- Contenu de la table `comment`
--

INSERT INTO `comment` (`idc`, `idbc`, `titrec`, `commentc`, `signalc`, `auteurc`, `datec`) VALUES
(39, 1, 'fan de jean forteroche', ' bravo tres bon roman ,mr forteroche .\r\nJe suis un fan .', 0, 'freddy mercuri', '2020-02-06'),
(40, 1, 'TELLEMENT MEDIOCRE', ' j ai toujours deteste vos romans, ils sont horribles ,ce dernier aussi ', 1, 'le corbeau', '2020-02-06'),
(41, 1, 'j adore', ' bonjour,j ai adore ce roman a la troisieme personne et les divers personnage de mr forteroche ,excellent!', 0, 'micheline de nice', '2020-02-06'),
(42, 2, 'bonne description', ' oui j ai bien aime le passage sur la peche cela reflette bien la realite .', 0, 'pecheur invetere', '2020-02-06'),
(43, 2, 'PLAGIAT', ' vous etes mediocre mr jean forteroche ,vous avez copie le roman de philippe,c est honteux', 1, 'le corbeau', '2020-02-06'),
(44, 2, 'admirable aventure', ' votre roman m a donne envie d aller visiter l alaska ,merci', 0, 'jacques de beauvais', '2020-02-06'),
(45, 5, 'j adore chasser', ' bonjour jean \r\nformidable roman ,surtout le passage sur la chasse.', 0, 'braconier en herbe', '2020-02-06'),
(46, 5, 'la chasse une aberation', ' vous allez voir mr forteroche ,on va vous mettre un proces sur le dos pour incitation a chasser!!!', 1, 'green peace', '2020-02-06'),
(47, 5, 'UN PURE  CHEF D OEUVRE', ' j ai adore votre roman du debut a la fin ,un grand merci', 0, 'marc de bretagne', '2020-02-06'),
(48, 6, 'belle description', ' vous faites une bonne description des fleurs d alaska ,c est apreciable', 0, 'manon fleuriste', '2020-02-06'),
(49, 6, 'pas mal du tout', ' c est pas mal tout ca ,bravo!', 0, 'archeologue', '2020-02-06'),
(50, 6, 'arrogance de j forteroche', ' et voila que maintenant ,vous vous faites passer pour un botaniste!\r\nc est navrant', 1, 'le corbeau', '2020-02-06'),
(51, 7, 'magnifique', ' le passage sur le glacier etait vraiment saisissant meme terrible,bravo', 0, 'trappeur du sud', '2020-02-06'),
(52, 7, 'je veux visiter l alaska moi', ' votre livre me donne envie de visiter l alaska ,ce sera ma prochaine destination merci', 0, 'micheline marseille', '2020-02-06'),
(53, 7, 'tricheur voleurmenteur', ' vous copiez allegrement les autres ecrivains ,c est honteux ', 1, 'le corbeau', '2020-02-06');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `idbc_c` FOREIGN KEY (`idbc`) REFERENCES `billet` (`idb`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
